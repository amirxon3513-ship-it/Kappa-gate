// Records the product demo video: types a prompt on the test bench and scrolls through the evidence
// (how many sources confirm or refute each fact). Needs: node, playwright, ffmpeg.
//
//   node tests/record_demo.js                        # against http://127.0.0.1:8080, writes ./demo_out/kappa_gate_demo.mp4
//   BASE=http://localhost:8080 DEMO_MODE=ai node tests/record_demo.js     # with real keys on the server: Nemotron mode
//   DEMO_MODE=live PROMPT="What is the capital of Uzbekistan?" DEMO_KB=0 node tests/record_demo.js
//
// DEMO_MODE: auto (default: ai if the server has a Nebius key, else the local engine) | local | ai | live
// DEMO_KB=0 keeps the page's own knowledge base instead of examples/demo_kb_en.json (use it for live mode).
const { chromium } = require('playwright');
const fs = require('fs');
const path = require('path');
const { execFileSync } = require('child_process');

const BASE = process.env.BASE || 'http://127.0.0.1:8080';
const OUT = path.resolve(process.env.OUT || 'demo_out');
const PROMPT = process.env.PROMPT || 'How many months is the warranty on appliances?';
const WANT = process.env.DEMO_MODE || 'auto';
const USE_KB = process.env.DEMO_KB !== '0';
const KB = fs.readFileSync(path.join(__dirname, '../examples/demo_kb_en.json'), 'utf8');
const sleep = ms => new Promise(r => setTimeout(r, ms));

const OVERLAY = () => {
  const st = document.createElement('style');
  st.textContent = `
  #kg-cursor{position:fixed;left:0;top:0;width:26px;height:26px;z-index:2147483647;pointer-events:none;transform:translate(640px,360px);transition:transform .85s cubic-bezier(.45,.05,.25,1);filter:drop-shadow(0 2px 3px rgba(0,0,0,.35))}
  #kg-click{position:fixed;z-index:2147483646;pointer-events:none;width:34px;height:34px;margin:-17px 0 0 -17px;border-radius:50%;border:3px solid #2F3FE0;opacity:0;transform:scale(.4)}
  #kg-click.go{animation:kgc .5s ease-out}
  @keyframes kgc{0%{opacity:.9;transform:scale(.4)}100%{opacity:0;transform:scale(1.5)}}
  #kg-cap{position:fixed;left:50%;bottom:26px;transform:translateX(-50%);max-width:1000px;z-index:2147483645;pointer-events:none;background:rgba(13,26,33,.93);color:#fff;font:500 21px/1.35 Onest,system-ui,sans-serif;padding:13px 24px;border-radius:12px;text-align:center;opacity:0;transition:opacity .35s;box-shadow:0 6px 24px rgba(0,0,0,.3)}
  #kg-cap.on{opacity:1}
  #kg-ring{position:fixed;z-index:2147483644;pointer-events:none;border:3px solid #2F3FE0;border-radius:10px;box-shadow:0 0 0 6px rgba(47,63,224,.18);opacity:0;transition:opacity .3s,left .4s,top .4s,width .4s,height .4s}
  #kg-ring.on{opacity:1}`;
  document.head.append(st);
  const c = document.createElement('div'); c.id = 'kg-cursor';
  c.innerHTML = '<svg viewBox="0 0 24 24" width="26" height="26"><path d="M3 2l17 8.5-7.2 2.2L9.8 20z" fill="#fff" stroke="#0D1A21" stroke-width="1.6" stroke-linejoin="round"/></svg>';
  const k = document.createElement('div'); k.id = 'kg-click';
  const cap = document.createElement('div'); cap.id = 'kg-cap';
  const ring = document.createElement('div'); ring.id = 'kg-ring';
  document.body.append(ring, k, c, cap);
  window.__kg = {
    move: (x, y) => { c.style.transform = `translate(${x - 4}px,${y - 3}px)`; },
    click: (x, y) => { k.style.left = x + 'px'; k.style.top = y + 'px'; k.classList.remove('go'); void k.offsetWidth; k.classList.add('go'); },
    caption: t => { if (!t) { cap.classList.remove('on'); return; } cap.textContent = t; cap.classList.add('on'); },
    ring: r => { if (!r) { ring.classList.remove('on'); return; } const p = 8; Object.assign(ring.style, { left: r.x - p + 'px', top: r.y - p + 'px', width: r.w + 2 * p + 'px', height: r.h + 2 * p + 'px' }); ring.classList.add('on'); },
    scrollTo: (y, ms) => new Promise(res => {
      const y0 = scrollY, d = y - y0, t0 = performance.now();
      const ease = t => (t < .5 ? 2 * t * t : 1 - Math.pow(-2 * t + 2, 2) / 2);
      const step = now => { const t = Math.min(1, (now - t0) / ms); scrollTo(0, y0 + d * ease(t)); t < 1 ? requestAnimationFrame(step) : res(); };
      requestAnimationFrame(step);
    })
  };
};

(async () => {
  fs.mkdirSync(OUT, { recursive: true });
  const tmp = fs.mkdtempSync(path.join(OUT, 'raw-'));
  const browser = await chromium.launch();
  const ctx = await browser.newContext({ viewport: { width: 1280, height: 720 }, recordVideo: { dir: tmp, size: { width: 1280, height: 720 } } });
  if (USE_KB) await ctx.addInitScript(kb => { try { localStorage.setItem('cl-gateway-kb-v1', kb); } catch (e) { /* ignore */ } }, KB);
  const page = await ctx.newPage();
  await page.goto(BASE + '/index_en.html');
  await page.evaluate(OVERLAY);
  await page.waitForTimeout(600);

  const status = await page.evaluate(() => fetch('/api/status').then(r => r.json()).catch(() => null));
  let mode = WANT === 'auto' ? (status && status.nebius ? 'ai' : 'local') : WANT;
  if (mode !== 'local' && !(status && status.nebius)) { console.log('Server has no Nebius key: falling back to the local engine.'); mode = 'local'; }
  if (mode === 'live' && !(status && status.tavily)) { console.log('Server has no Tavily key: using Nemotron mode.'); mode = 'ai'; }
  console.log('Recording in mode:', mode);

  const cap = (t) => page.evaluate(t => window.__kg.caption(t), t);
  const center = async sel => { const b = await page.locator(sel).first().boundingBox(); return { x: b.x + b.width / 2, y: b.y + Math.min(b.height / 2, 30) }; };
  const moveTo = async (sel, dx = 0) => { const p = await center(sel); await page.evaluate(([x, y]) => window.__kg.move(x, y), [p.x + dx, p.y]); await sleep(950); return p; };
  const clickOn = async (sel, dx = 0) => { const p = await moveTo(sel, dx); await page.evaluate(([x, y]) => window.__kg.click(x, y), [p.x + dx, p.y]); await sleep(150); await page.click(sel); await sleep(350); };
  const scrollTo = (y, ms = 1800) => page.evaluate(([y, ms]) => window.__kg.scrollTo(y, ms), [y, ms]);
  const ringEl = async sel => { const b = await (typeof sel === 'string' ? page.locator(sel).first() : sel).boundingBox(); await page.evaluate(r => window.__kg.ring(r), b ? { x: b.x, y: b.y, w: b.width, h: b.height } : null); };
  const noRing = () => page.evaluate(() => window.__kg.ring(null));
  const absTop = sel => page.evaluate(s => { const e = document.querySelector(s); return e ? e.getBoundingClientRect().top + scrollY : 0; }, sel);

  // 1. home
  await cap('Kappa Gate: an anti-hallucination gateway for RAG. No context, no answer.');
  await sleep(3500);
  await scrollTo(380, 2200); await sleep(1800);
  await cap('Every statement gets an integer context K. Only K ≥ 1 reaches the answer.');
  await sleep(3200);
  await scrollTo(0, 1500); await sleep(600);

  // 2. test bench
  await cap('The test bench: ask a question against a knowledge base.');
  await clickOn('#tabs a[data-tab="stand"]');
  await sleep(1200);
  await page.waitForSelector('#runBtn', { state: 'visible' });
  if (mode !== 'local') { await clickOn(`#modeSeg [data-mode="${mode}"]`); }
  await scrollTo(await absTop('#q') - 120, 1200); await sleep(700);

  // 3. type the prompt
  await cap(mode === 'local' ? 'Recorded in Local engine mode: the K-engine runs here without any AI call.' : 'Nemotron on Nebius Token Factory annotates the query; the K-engine decides.');
  await clickOn('#q');
  await page.fill('#q', '');
  await page.keyboard.type(PROMPT, { delay: 75 });
  await sleep(900);

  // 4. run
  await cap('Run the check.');
  await clickOn('#runBtn');
  await page.waitForFunction(() => !document.getElementById('runBtn').disabled, null, { timeout: 90000 });
  await page.waitForSelector('#evidence .evrow, #liveInfo .evrow', { timeout: 30000 });
  await sleep(500);
  await cap('The engine sorts every fact into True, Unknown or False by the sign of K.');
  await scrollTo(await absTop('#results') - 60, 1800); await sleep(2600);

  // 5. plain RAG vs the gate
  await cap('Ordinary RAG puts the whole context into the prompt, false and unverified facts included.');
  await ringEl('#naiveCtx'); await sleep(4200); await noRing();

  // 6. the evidence: how many sources confirm or refute each fact
  if (mode === 'live') { await cap('Tavily search results: each domain is one source, its class sets the weight.'); await scrollTo(await absTop('#liveInfo') - 80, 1800); await ringEl('#liveInfo .evid'); await sleep(5000); await noRing(); }
  await cap('Now the evidence behind each fact: how many sources confirm it and how many refute it.');
  await scrollTo(await absTop('#evidence') - 90, 2200); await sleep(2600);
  const rows = await page.locator('#evidence .evrow').count();
  const texts = [];
  for (let i = 0; i < rows; i++) texts.push((await page.locator('#evidence .evrow').nth(i).innerText()).replace(/\s+/g, ' '));
  for (let i = 0; i < rows; i++) {
    const t = texts[i];
    const set = /^[TFU]/.test(t) ? t[0] : '?';
    const msg = set === 'T' ? 'Verified (T): this many sources confirm it, this many refute it. K is the sum of their weights.'
      : set === 'F' ? 'False (F): K is negative. Blocked, it never reaches the model.'
      : 'Unknown (U): K = 0. Quarantined, not presented as knowledge.';
    await cap(msg);
    await ringEl(page.locator('#evidence .evrow').nth(i));
    await sleep(set === 'T' ? 6500 : 4200);
  }
  await noRing();

  // 7. the verified answer
  await cap('Only verified facts form the answer, with their sources attached. Blocked and quarantined facts stay out.');
  await scrollTo(await absTop('#finalAnswer') - 200, 2000); await sleep(1500);
  const fa = page.locator('#finalAnswer .claims').first();
  if (await fa.count()) { await ringEl('#finalAnswer .claims'); }
  await sleep(5000); await noRing();

  // 8. end card
  await cap(mode === 'local' ? 'Kappa Gate · No context, no answer.' : 'Kappa Gate · Nemotron on Nebius Token Factory' + (mode === 'live' ? ' · Tavily' : '') + ' · No context, no answer.');
  await sleep(3800);
  await cap(null); await sleep(500);

  const vpath = await page.video().path();
  await ctx.close(); await browser.close();
  const mp4 = path.join(OUT, 'kappa_gate_demo.mp4');
  execFileSync('ffmpeg', ['-y', '-loglevel', 'error', '-i', vpath, '-c:v', 'libx264', '-preset', 'veryfast', '-crf', '20', '-pix_fmt', 'yuv420p', '-movflags', '+faststart', '-an', mp4]);
  fs.rmSync(tmp, { recursive: true, force: true });
  console.log('Saved', mp4);
})().catch(e => { console.error(e); process.exit(1); });
