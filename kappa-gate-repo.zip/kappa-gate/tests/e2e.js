// End-to-end browser test against server.py with the mock upstream (see tests/mock_upstream.py)
const { chromium } = require('playwright');
const BASE = process.env.BASE || 'http://127.0.0.1:8090';
const OUT = process.env.OUT || '/tmp';
let failed = 0;
const ok = (c, m) => { console.log((c ? 'PASS ' : 'FAIL ') + m); if (!c) failed++; };

async function run(page, mode, query) {
  await page.click(`#modeSeg [data-mode="${mode}"]`);
  await page.fill('#q', query);
  await page.click('#runBtn');
  await page.waitForFunction(() => !document.getElementById('runBtn').disabled, null, { timeout: 30000 });
  return {
    verdict: (await page.innerText('#verdict')).replace(/\s+/g, ' '),
    answer: (await page.innerText('#finalAnswer')).replace(/\s+/g, ' '),
    live: (await page.innerText('#liveInfo')).replace(/\s+/g, ' '),
    naive: (await page.innerText('#naiveOut')).replace(/\s+/g, ' '),
    label: await page.innerText('#srcLabel'),
    stages: (await page.innerText('#stages')).replace(/\s+/g, ' ')
  };
}

(async () => {
  const browser = await chromium.launch();
  for (const [file, lang] of [['index_en.html', 'en'], ['index.html', 'ru']]) {
    const page = await browser.newPage({ viewport: { width: 1280, height: 1000 } });
    const errors = []; const external = [];
    page.on('pageerror', e => errors.push('pageerror: ' + e.message));
    page.on('console', m => { if (m.type() === 'error' && !/ERR_TUNNEL_CONNECTION_FAILED|ERR_NAME_NOT_RESOLVED|fonts\./.test(m.text())) errors.push('console: ' + m.text()); }); // web fonts cannot load in the sandbox
    page.on('request', r => { const u = r.url(); if (!u.startsWith(BASE) && !u.startsWith('data:') && !/fonts\.(googleapis|gstatic)\.com/.test(u)) external.push(u); });
    await page.goto(`${BASE}/${file}`);
    await page.waitForFunction(() => !document.querySelector('#modeSeg [data-mode="ai"]').disabled, null, { timeout: 10000 }).catch(() => {});
    const aiOn = await page.$eval('#modeSeg [data-mode="ai"]', b => !b.disabled);
    const liveOn = await page.$eval('#modeSeg [data-mode="live"]', b => !b.disabled);
    ok(aiOn && liveOn, `[${lang}] Nemotron and Live buttons enabled`);
    ok(/nemotron/i.test(await page.innerText('#aiNote')), `[${lang}] note mentions Nemotron + model ids`);

    await page.evaluate(() => { location.hash = '#stand'; });
    await page.waitForSelector('#runBtn', { state: 'visible' });
    // 1. AI mode, ordinary question against the demo knowledge base
    const q1 = lang === 'en' ? 'At what temperature does water boil?' : 'При какой температуре кипит вода?';
    let r = await run(page, 'ai', q1);
    ok(/nemotron/i.test(r.label) && !/activeengine/i.test(r.label), `[${lang}] AI mode label: ${r.label}`);
    ok(/MOCK naive answer/.test(r.naive), `[${lang}] ordinary RAG pane answered by the model`);
    ok(r.verdict.length > 0 && !/Error|Ошибка/.test(r.verdict), `[${lang}] AI verdict ok: ${r.verdict.slice(0, 90)}`);

    // 2. liar paradox must be quarantined with K = 0
    r = await run(page, 'ai', lang === 'en' ? 'This statement is false' : 'Это утверждение ложно');
    ok(/K = 0/.test(r.verdict), `[${lang}] paradox gives K = 0: ${r.verdict.slice(0, 90)}`);

    // 3. Live mode through Tavily
    r = await run(page, 'live', lang === 'en' ? 'What is the capital of Uzbekistan?' : 'What is the capital of Uzbekistan?');
    ok(/gov\.uz/.test(r.live) && /britannica\.com/.test(r.live) && /reddit\.com/.test(r.live), `[${lang}] live panel lists the 3 pages`);
    ok(/web|интернет/i.test(r.label) && /tavily/i.test(r.label) && !/activeengine/i.test(r.label), `[${lang}] live label: ${r.label}`);
    ok(/Tashkent/.test(r.answer), `[${lang}] verified answer contains Tashkent`);
    ok(!/Samarkand/.test(r.answer.split(/Blocked|Заблок|quarantine|карантин/i)[0]), `[${lang}] Samarkand (reddit, K=0) is not in the verified answer`);
    console.log(`[${lang}] live verdict:`, r.verdict.slice(0, 120));
    console.log(`[${lang}] live answer :`, r.answer.slice(0, 260));
    await page.screenshot({ path: `${OUT}/kappa_${lang}_live.png`, fullPage: false });
    await page.locator('#results').screenshot({ path: `${OUT}/kappa_${lang}_results.png` });

    // 4. live mode with a paradox: no Tavily call
    const before = await (await fetch('http://127.0.0.1:9101/__log')).json();
    r = await run(page, 'live', lang === 'en' ? 'This statement is false' : 'Это утверждение ложно');
    const after = await (await fetch('http://127.0.0.1:9101/__log')).json();
    ok(after.filter(x => x[1] === '/search').length === before.filter(x => x[1] === '/search').length, `[${lang}] paradox skipped the web search`);
    ok(/K = 0/.test(r.verdict), `[${lang}] live paradox K = 0`);

    // 5. export download works without window.claude
    await page.goto(`${BASE}/${file}#data`);
    const [dl] = await Promise.all([page.waitForEvent('download', { timeout: 5000 }).catch(() => null), page.click('#btnDownload')]);
    ok(!!dl && dl.suggestedFilename() === 'contextual-logic-kb.json', `[${lang}] JSON download works`);

    ok(errors.length === 0, `[${lang}] no console/page errors ${errors.join(' | ').slice(0, 300)}`);
    ok(external.length === 0, `[${lang}] no third-party requests ${external.join(',').slice(0, 200)}`);
    await page.close();
  }
  await browser.close();
  console.log(failed ? `\n${failed} FAILED` : '\nALL PASSED');
  process.exit(failed ? 1 : 0);
})();
